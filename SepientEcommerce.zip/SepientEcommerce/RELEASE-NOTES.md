Release changes in version 2.9.0


- REST api enhancements !
- Github issues
- New theme

